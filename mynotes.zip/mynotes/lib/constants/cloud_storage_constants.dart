const ownerUserIdFieldName = 'user_id';
const textFieldName = 'text';
