package se.pixolity.mynotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
